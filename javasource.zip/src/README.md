Lambda functions and backend code goes here
